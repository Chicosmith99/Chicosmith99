const STORAGE_KEYS = {
  CUSTOM_SPAM_PATTERNS: 'customSpamPatterns',
  WHITELIST: 'whitelist',
  // Add other keys as needed
};

// Get custom spam patterns from chrome storage
async function getCustomSpamPatterns() {
  return new Promise((resolve) => {
    chrome.storage.sync.get([STORAGE_KEYS.CUSTOM_SPAM_PATTERNS], (result) => {
      resolve(result[STORAGE_KEYS.CUSTOM_SPAM_PATTERNS] || []);
    });
  });
}

// Set custom spam patterns to chrome storage
async function setCustomSpamPatterns(patterns) {
  return new Promise((resolve) => {
    chrome.storage.sync.set({ [STORAGE_KEYS.CUSTOM_SPAM_PATTERNS]: patterns }, () => {
      resolve();
    });
  });
}

// Generic getStorage function
async function getStorage(key) {
  return new Promise((resolve) => {
    chrome.storage.sync.get([key], (result) => {
      resolve(result[key]);
    });
  });
}

// Generic setStorage function
async function setStorage(key, value) {
  return new Promise((resolve) => {
    chrome.storage.sync.set({ [key]: value }, () => {
      resolve();
    });
  });
}

export { getCustomSpamPatterns, setCustomSpamPatterns, getStorage, setStorage, STORAGE_KEYS };
